#ifndef _H_tuple
#define _H_tuple

#include <iostream>
#include <vector>

#include "../../../common-libs/domain-obj/structure.h"

class ProgramArgs;
class Node;
class Element;
class LLPartition;

class ProgramArgs {
  public:
	int a1;
	int a2;
	int a3;
	int b1;
	int b2;
	int b3;
	int iterations;
	int mesh_size;
	int pa1;
	int pa2;
	int pa3;
	int pb1;
	int pb2;
	int pb3;
	ProgramArgs() {
		a1 = 0;
		a2 = 0;
		a3 = 0;
		b1 = 0;
		b2 = 0;
		b3 = 0;
		iterations = 0;
		mesh_size = 0;
		pa1 = 0;
		pa2 = 0;
		pa3 = 0;
		pb1 = 0;
		pb2 = 0;
		pb3 = 0;
	}
};

class Node {
  public:
	double x;
	double y;
	double z;
	double xd;
	double yd;
	double zd;
	double xdd;
	double ydd;
	double zdd;
	double fx;
	double fy;
	double fz;
	Node() {
		x = 0;
		y = 0;
		z = 0;
		xd = 0;
		yd = 0;
		zd = 0;
		xdd = 0;
		ydd = 0;
		zdd = 0;
		fx = 0;
		fy = 0;
		fz = 0;
	}
};

class Element {
  public:
	double p;
	double q;
	double normalX[2][2][2];
	double normalY[2][2][2];
	double normalZ[2][2][2];
	double volume;
	double sigxx;
	double sigyy;
	double sigzz;
	Element() {
		p = 0;
		q = 0;
		normalX = NULL;
		normalY = NULL;
		normalZ = NULL;
		volume = 0;
		sigxx = 0;
		sigyy = 0;
		sigzz = 0;
	}
};

class LLPartition {
  public:
	int a1;
	int a2;
	int a3;
	int b1;
	int b2;
	int b3;
	int pa1;
	int pa2;
	int pa3;
	int pb1;
	int pb2;
	int pb3;
	LLPartition() {
		a1 = 0;
		a2 = 0;
		a3 = 0;
		b1 = 0;
		b2 = 0;
		b3 = 0;
		pa1 = 0;
		pa2 = 0;
		pa3 = 0;
		pb1 = 0;
		pb2 = 0;
		pb3 = 0;
	}
};

#endif
